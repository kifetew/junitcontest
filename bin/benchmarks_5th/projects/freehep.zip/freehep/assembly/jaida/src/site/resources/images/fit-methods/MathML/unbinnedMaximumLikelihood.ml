<math>
<mstyle fontsize="25">
<mrow>
  <mtext>uml</mtext>
  <mo>=</mo>
  <mi>-</mi>
  <munder>
    <mi>&sum;</mi>
    <mi>i</mi>
  </munder>
  <mtext>ln</mtext>
  <mfenced>
    <mrow>
      <mi>f</mi>
      <mfenced>
        <msub>
          <mi>x</mi>
          <mi>i</mi>
        </msub>
      </mfenced>
    </mrow>
  </mfenced>
</mrow>
</mstyle>
</math>




