<math>
  <mstyle fontsize="25">
    <mrow>
      <msub>
        <mi>h</mi>
        <mi>i</mi>
      </msub>
    </mrow>
  </mstyle>
</math>
