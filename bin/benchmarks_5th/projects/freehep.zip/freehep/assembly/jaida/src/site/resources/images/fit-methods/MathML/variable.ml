<math>
  <mstyle fontsize="25">
    <mrow>
      <msub>
        <mi>x</mi>
        <mi>i</mi>
      </msub>
    </mrow>
  </mstyle>
</math>
