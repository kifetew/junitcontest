<math>
  <mstyle fontsize="25">
    <mrow>
      <msub>
        <mi>&sigma;</mi>
        <mi>i</mi>
      </msub>
    </mrow>
  </mstyle>
</math>
