<math>
  <mstyle fontsize="25">
    <mrow>
      <mi>f</mi>
      <mfenced>
        <msub>
          <mi>x</mi>
          <mi>i</mi>
        </msub>
      </mfenced>
    </mrow>
  </mstyle>
</math>
