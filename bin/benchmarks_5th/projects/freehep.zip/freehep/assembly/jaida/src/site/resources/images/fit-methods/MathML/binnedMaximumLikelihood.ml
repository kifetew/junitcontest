<math>
<mstyle fontsize="25">
<mrow>
  <mtext>bml</mtext>
  <mo>=</mo>
  <munder>
    <mi>&sum;</mi>
    <mi>i</mi>
  </munder>
  <mfenced>
   <mrow>
     <mi>f</mi>
     <mfenced>
    <msub>
      <mi>x</mi>
      <mi>i</mi>
    </msub>
  </mfenced>
  <mi>-</mi>
  <msub>
    <mi>h</mi>
    <mi>i</mi>
  </msub>
  <mo> &InvisibleTimes; </mo>
  <mtext>ln</mtext>
  <mfenced>
    <mrow>
      <mi>f</mi>
      <mfenced>
        <msub>
          <mi>x</mi>
          <mi>i</mi>
        </msub>
      </mfenced>
    </mrow>
  </mfenced>
</mrow>
</mfenced>
</mrow>
</mstyle>
</math>




