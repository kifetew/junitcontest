For information on JAIDA see:

http://java.freehep.org/jaida
