package org.freehep.util.parameterdatabase;

public interface DatabaseListener {

    public void databaseUpdated();
}
