package org.freehep.util;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author onoprien
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({org.freehep.util.VersionComparatorTest.class})
public class TestSuite {

  @BeforeClass
  public static void setUpClass() throws Exception {
  }

  @AfterClass
  public static void tearDownClass() throws Exception {
  }
  
}
