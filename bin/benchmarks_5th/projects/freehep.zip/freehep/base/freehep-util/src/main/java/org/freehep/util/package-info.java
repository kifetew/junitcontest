/**
 * Generic utility classes used by FreeHEP libraries.
 */
package org.freehep.util;
