/**
 * Machinery for encapsulating record sources.
 */
package org.freehep.record.source;
