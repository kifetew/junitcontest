/**
 * Classes that handle fetching records from sources and serving them to consumers.
 */
package org.freehep.record.loop;
