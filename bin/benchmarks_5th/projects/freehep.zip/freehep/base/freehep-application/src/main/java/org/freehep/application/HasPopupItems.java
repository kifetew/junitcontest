package org.freehep.application;

/**
 * Just kept for backwards compatibility.
 *
 * @author Tony Johnson (tonyj@slac.stanford.edu)
 * @version $Id: HasPopupItems.java 14082 2012-12-12 16:16:53Z tonyj $
 * @deprecated Use org.freehep.swing.popup.HasPopupItems instead.
 */
public interface HasPopupItems extends org.freehep.swing.popup.HasPopupItems {
}
