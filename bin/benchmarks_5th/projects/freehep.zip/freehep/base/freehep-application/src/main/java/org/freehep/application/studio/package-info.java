/**
 * Classes used by interactive applications that can be extended with plugins.
 */
package org.freehep.application.studio;
