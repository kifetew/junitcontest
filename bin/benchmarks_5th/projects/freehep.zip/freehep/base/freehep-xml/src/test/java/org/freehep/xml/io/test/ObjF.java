/*
 * ObjF.java
 *
 * Created on July 15, 2002, 4:16 PM
 */

package org.freehep.xml.io.test;

/**
 *
 * @author  turri
 */
public class ObjF extends AbstractObj {
    
    public ObjF() {
    }
    public ObjF(int status) {
        super(status);
    }
}