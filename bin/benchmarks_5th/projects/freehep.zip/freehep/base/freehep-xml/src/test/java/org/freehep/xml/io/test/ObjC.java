/*
 * ObjC.java
 *
 * Created on July 15, 2002, 4:16 PM
 */

package org.freehep.xml.io.test;

/**
 *
 * @author  turri
 */
public class ObjC extends ObjA {
    
    /** Creates a new instance of ObjC */
    public ObjC() {
    }
    public ObjC(int status) {
        super(status);
    }
    
}