/*
 * ObjD.java
 *
 * Created on July 15, 2002, 4:16 PM
 */

package org.freehep.xml.io.test;

/**
 *
 * @author  turri
 */
public class ObjD extends AbstractObj {
    
    public ObjD() {
    }
    public ObjD(int status) {
        super(status);
    }
}