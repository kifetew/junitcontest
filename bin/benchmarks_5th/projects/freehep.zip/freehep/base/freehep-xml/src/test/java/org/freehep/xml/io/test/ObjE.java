/*
 * ObjE.java
 *
 * Created on July 15, 2002, 4:16 PM
 */

package org.freehep.xml.io.test;

/**
 *
 * @author  turri
 */
public class ObjE extends AbstractObj {
    
    public ObjE() {
    }
    public ObjE(int status) {
        super(status);
    }
}