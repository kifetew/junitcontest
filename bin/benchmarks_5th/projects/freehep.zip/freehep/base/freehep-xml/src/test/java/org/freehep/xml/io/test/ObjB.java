/*
 * ObjB.java
 *
 * Created on July 15, 2002, 4:16 PM
 */

package org.freehep.xml.io.test;

/**
 *
 * @author  turri
 */
public class ObjB extends ObjA {
    
    /** Creates a new instance of ObjB */
    public ObjB() {
    }
    public ObjB(int status) {
        super(status);
    }

}
