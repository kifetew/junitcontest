package jas.hist;
public interface FitListener extends java.util.EventListener
{
	abstract public void fitStarted(Fitter f);
}
