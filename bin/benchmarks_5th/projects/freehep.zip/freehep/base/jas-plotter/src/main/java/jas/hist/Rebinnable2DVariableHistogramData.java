package jas.hist;

public interface Rebinnable2DVariableHistogramData
	extends Rebinnable2DHistogramData
{
        public double[] getXBinEdges();
        public double[] getYBinEdges();
}
