package jas.hist;

public class InvalidFunctionParameter extends Exception
{
	public InvalidFunctionParameter(String s)
	{
		super(s);
	}
}
