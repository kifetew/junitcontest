package jas.hist;

public class IndeterminateMatrix extends Exception{};
