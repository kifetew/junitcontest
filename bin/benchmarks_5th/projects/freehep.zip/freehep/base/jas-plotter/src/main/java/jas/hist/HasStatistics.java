package jas.hist;

public interface HasStatistics
{
	Statistics getStatistics(); // return a refreshed object (with most recent values)
}
