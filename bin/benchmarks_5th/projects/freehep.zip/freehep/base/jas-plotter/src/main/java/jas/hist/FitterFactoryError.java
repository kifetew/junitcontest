package jas.hist;

class FitterFactoryError extends Exception
{
	public FitterFactoryError(String s)
	{
		super(s);
	}
}
