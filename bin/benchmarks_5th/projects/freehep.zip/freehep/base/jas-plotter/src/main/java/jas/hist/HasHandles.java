package jas.hist;

public interface HasHandles
{
	public abstract Handle[] getHandles(double xlow, double xhigh, double ylow, double yhigh);
}
