package jas.hist;

public class FitFailed extends Exception
{
	public FitFailed(String s)
	{
		super(s);
	}
}
