package jas.hist;
import jas.plot.Overlay;

public interface CustomOverlay extends Overlay
{
	void setDataSource(DataSource source);
}