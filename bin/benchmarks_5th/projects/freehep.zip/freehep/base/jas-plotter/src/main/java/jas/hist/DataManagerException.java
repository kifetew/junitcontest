package jas.hist;

final class DataManagerException extends RuntimeException
{
	DataManagerException(String s) { super(s); }
}
