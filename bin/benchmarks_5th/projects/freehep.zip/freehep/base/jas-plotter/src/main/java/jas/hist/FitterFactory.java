package jas.hist;

public interface FitterFactory
{
	Fitter createFitter();
	String getFitterName();
}
