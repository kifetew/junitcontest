package jas.hist;

public interface HasDataSource
{
	public DataSource getDataSource(String param);
}
