package jas.hist;

public class FunctionFactoryError extends Exception
{
	public FunctionFactoryError(String s)
	{
		super(s);
	}
}
