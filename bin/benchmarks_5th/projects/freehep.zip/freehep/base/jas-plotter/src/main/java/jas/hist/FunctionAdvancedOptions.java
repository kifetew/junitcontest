package jas.hist;
import java.awt.Frame;

public interface FunctionAdvancedOptions
{
	public void openAdvancedDialog(Frame f, JASHist hist);
}
