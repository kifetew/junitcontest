package jas.hist;

public class FunctionValueUndefined extends Exception{}
